'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { getProfile, PublicApiError } from '@/lib/api';
import { darken } from '@/lib/theme';
import { usePublicBookingStore } from '@/store/publicBooking.store';
import { Services } from '@/components/booking/Services';
import { Professionals } from '@/components/booking/Professionals';
import { Calendar } from '@/components/booking/Calendar';
import { TimeSlots } from '@/components/booking/TimeSlots';
import { PhoneStep } from '@/components/otp/PhoneStep';
import { OtpStep } from '@/components/otp/OtpStep';
import { IdentifyStep } from '@/components/otp/IdentifyStep';
import { Confirm } from '@/components/booking/Confirm';
import { Success } from '@/components/booking/Success';

export default function PublicPage() {
  const params = useParams();
  const slug = typeof params?.slug === 'string' ? params.slug : '';

  const step = usePublicBookingStore(s => s.step);
  const profile = usePublicBookingStore(s => s.profile);
  const setProfile = usePublicBookingStore(s => s.setProfile);
  const setSlug = usePublicBookingStore(s => s.setSlug);
  const back = usePublicBookingStore(s => s.back);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!slug) return;

    let active = true;
    setSlug(slug);

    getProfile(slug)
      .then(p => {
        if (active) setProfile(p);
      })
      .catch((e: unknown) => {
        if (active) {
          setError(e instanceof PublicApiError ? e.message : 'Não foi possível carregar.');
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [slug, setProfile, setSlug]);

  // Personalização: aplica a cor da marca do estabelecimento nas CSS vars
  // globais (--brand, --brand-strong, --background). Usamos primitivos nas deps
  // pro React Compiler e restauramos os valores ao desmontar.
  const primary = profile?.business.theme?.primary;
  const bg = profile?.business.theme?.bg;

  useEffect(() => {
    if (!primary || !bg) return;

    const root = document.documentElement;
    const next: Record<string, string> = {
      '--brand': primary,
      '--brand-strong': darken(primary, 0.14),
      '--background': bg,
    };

    const prev: Record<string, string> = {};
    Object.keys(next).forEach(k => {
      prev[k] = root.style.getPropertyValue(k);
      root.style.setProperty(k, next[k]);
    });

    return () => {
      Object.keys(next).forEach(k => {
        if (prev[k]) root.style.setProperty(k, prev[k]);
        else root.style.removeProperty(k);
      });
    };
  }, [primary, bg]);

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-neutral-300 border-t-brand" />
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-2 text-center">
        <p className="font-medium text-neutral-900">Estabelecimento não encontrado</p>
        {error && <p className="text-sm text-neutral-500">{error}</p>}
      </div>
    );
  }

  const showBack = step !== 'service' && step !== 'success';
  const location = [profile.business.city, profile.business.state].filter(Boolean).join(' · ');

  return (
    <div className="space-y-6">
      <header className="flex items-center gap-3 pt-2">
        {showBack && (
          <button
            type="button"
            onClick={back}
            aria-label="Voltar"
            className="glass flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-neutral-700"
          >
            ←
          </button>
        )}
        <div className="min-w-0">
          <h1 className="truncate text-base font-semibold text-neutral-900">
            {profile.business.name}
          </h1>
          {location && <p className="truncate text-xs text-neutral-500">{location}</p>}
        </div>
      </header>

      <div key={step} className="animate-[fadeIn_0.25s_ease]">
        {step === 'service' && <Services />}
        {step === 'professional' && <Professionals />}
        {step === 'date' && <Calendar />}
        {step === 'time' && <TimeSlots />}
        {step === 'phone' && <PhoneStep />}
        {step === 'otp' && <OtpStep />}
        {step === 'identify' && <IdentifyStep />}
        {step === 'confirm' && <Confirm />}
        {step === 'success' && <Success />}
      </div>
    </div>
  );
}
