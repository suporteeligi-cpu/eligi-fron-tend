import type { BusinessTheme } from '@/lib/theme';

export interface PublicBusiness {
  id: string;
  slug: string;
  name: string;
  segment: string | null;
  city: string | null;
  state: string | null;
  timezone: string;
  /** Personalização de cores do perfil público (sempre normalizado pelo backend). */
  theme: BusinessTheme;
}
export interface PublicHour {
  weekday: number;
  startTime: string;
  endTime: string;
}
export interface PublicService {
  id: string;
  name: string;
  duration: number;
  price: number | null;
  category: string | null;
  color: string | null;
  description: string | null;
}
export interface PublicProfessional {
  id: string;
  name: string;
  avatarUrl: string | null;
  role: string | null;
  description: string | null;
  serviceIds: string[];
}
export interface PublicSettings {
  minBookingNotice: number;
  maxFutureBookingDays: number;
  slotStep: number;
}
export interface PublicProfile {
  business: PublicBusiness;
  hours: PublicHour[];
  services: PublicService[];
  professionals: PublicProfessional[];
  settings: PublicSettings;
}
export interface VerifyResult {
  token: string;
  client: {
    id: string;
    name: string;
    phone: string;
    email?: string | null;
    cpf?: string | null;
    recognized?: boolean;
  };
}
export interface ConfirmedBooking {
  id: string;
  startAt: string;
  endAt: string;
  clientName: string;
  professionalId: string | null;
  status: string;
}
