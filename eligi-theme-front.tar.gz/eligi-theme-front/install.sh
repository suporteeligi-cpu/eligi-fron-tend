#!/usr/bin/env bash
set -euo pipefail

PUBLIC_ROOT="${1:-$HOME/Documentos/eligi/front-end-public}"
DASH_ROOT="${2:-$HOME/Documentos/eligi/front-end}"
HERE="$(cd "$(dirname "$0")" && pwd)"

TS="$(date +%Y%m%d-%H%M%S)"

copy_set() {
  local label="$1"; local src_root="$2"; local dst_root="$3"; shift 3
  if [ ! -d "$dst_root" ]; then
    echo "✗ não achei $label em $dst_root"; exit 1
  fi
  local bk="$dst_root/.backup/theme-$TS"
  echo "[$label] $dst_root"
  echo "  backup: $bk"
  for rel in "$@"; do
    local src="$src_root/$rel"
    local dst="$dst_root/$rel"
    if [ -f "$dst" ]; then
      mkdir -p "$bk/$(dirname "$rel")"; cp "$dst" "$bk/$rel"
    fi
    mkdir -p "$(dirname "$dst")"; cp "$src" "$dst"
    echo "  ✓ $rel"
  done
  echo
}

copy_set "front-end-public" "$HERE/files-public" "$PUBLIC_ROOT" \
  "src/lib/theme.ts" \
  "src/types/public.ts" \
  "src/app/globals.css" \
  "src/app/[slug]/page.tsx"

copy_set "front-end (dashboard)" "$HERE/files-dashboard" "$DASH_ROOT" \
  "src/shared/theme.ts" \
  "src/features/settings/components/ProfileThemeEditor.tsx"

echo "──────────────────────────────────────────────"
echo "Pronto. Falta só MONTAR o editor no Config (dashboard):"
echo
echo "  import ProfileThemeEditor from '@/features/settings/components/ProfileThemeEditor'"
echo "  // dentro de 'Detalhes da empresa':"
echo "  <ProfileThemeEditor />"
echo
echo "Em cada repo, rode: npm run lint && npm run build && npm run deploy"
echo
echo "⚠ Confira o prefixo SETTINGS_BASE no ProfileThemeEditor.tsx"
echo "   (topo do arquivo) — precisa bater com onde o router business-settings"
echo "   está montado. Hoje está '/business-settings'."
echo "──────────────────────────────────────────────"
