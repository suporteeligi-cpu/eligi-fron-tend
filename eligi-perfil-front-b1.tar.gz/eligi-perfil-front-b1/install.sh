#!/usr/bin/env bash
set -euo pipefail
DASH="${1:-$HOME/Documentos/eligi/front-end}"
HERE="$(cd "$(dirname "$0")" && pwd)"
[ -d "$DASH/src" ] || { echo "✗ dashboard não achado em $DASH"; exit 1; }
TS="$(date +%Y%m%d-%H%M%S)"
copy(){ local rel="$1" bk="$DASH/.backup/perfil-b1-$TS"; [ -f "$DASH/$rel" ] && { mkdir -p "$bk/$(dirname "$rel")"; cp "$DASH/$rel" "$bk/$rel"; }; mkdir -p "$(dirname "$DASH/$rel")"; cp "$HERE/files-dashboard/$rel" "$DASH/$rel"; echo "  ✓ $rel"; }
copy "src/shared/profileTheme.ts"
copy "src/features/settings/components/ImageCropper.tsx"
echo; echo "Backup em $DASH/.backup/perfil-b1-$TS/"
echo "Builde o dashboard: cd \"$DASH\" && npm run lint && npm run build && git add -A && git commit -m 'feat: recortador + sanitizers perfil' && git push"
