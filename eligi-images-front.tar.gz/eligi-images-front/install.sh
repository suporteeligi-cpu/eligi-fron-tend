#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PUB="${1:-$HOME/Documentos/eligi/front-end-public}"
DASH="${2:-$HOME/Documentos/eligi/front-end}"
TS="$(date +%Y%m%d-%H%M%S)"

[ -d "$PUB/src" ]  || { echo "✗ front-public não achado em $PUB"; exit 1; }
[ -d "$DASH/src" ] || { echo "✗ dashboard não achado em $DASH"; exit 1; }

copy(){  # $1=root  $2=rel
  local root="$1" rel="$2" bk="$1/.backup/images-$TS"
  [ -f "$root/$rel" ] && { mkdir -p "$bk/$(dirname "$rel")"; cp "$root/$rel" "$bk/$rel"; }
  mkdir -p "$(dirname "$root/$rel")"
  cp "$HERE/files-public/$rel" "$root/$rel" 2>/dev/null || cp "$HERE/files-dashboard/$rel" "$root/$rel"
  echo "  ✓ $rel"
}

echo "── front-public ($PUB) ──"
cp "$HERE/files-public/src/lib/theme.ts"        "$PUB/src/lib/theme.ts"        && echo "  ✓ src/lib/theme.ts"
[ -f "$PUB/src/types/public.ts" ] && { mkdir -p "$PUB/.backup/images-$TS/src/types"; cp "$PUB/src/types/public.ts" "$PUB/.backup/images-$TS/src/types/public.ts"; }
cp "$HERE/files-public/src/types/public.ts"     "$PUB/src/types/public.ts"     && echo "  ✓ src/types/public.ts"
[ -f "$PUB/src/app/[slug]/page.tsx" ] && { mkdir -p "$PUB/.backup/images-$TS/src/app/[slug]"; cp "$PUB/src/app/[slug]/page.tsx" "$PUB/.backup/images-$TS/src/app/[slug]/page.tsx"; }
cp "$HERE/files-public/src/app/[slug]/page.tsx" "$PUB/src/app/[slug]/page.tsx" && echo "  ✓ src/app/[slug]/page.tsx"

echo "── dashboard ($DASH) ──"
cp "$HERE/files-dashboard/src/shared/profileTheme.ts" "$DASH/src/shared/profileTheme.ts" && echo "  ✓ src/shared/profileTheme.ts"
ED="src/features/settings/components/ProfileThemeEditor.tsx"
[ -f "$DASH/$ED" ] && { mkdir -p "$DASH/.backup/images-$TS/$(dirname "$ED")"; cp "$DASH/$ED" "$DASH/.backup/images-$TS/$ED"; }
cp "$HERE/files-dashboard/$ED" "$DASH/$ED" && echo "  ✓ $ED"
PG="src/app/dashboard/configuracoes/empresa/page.tsx"
[ -f "$DASH/$PG" ] && { mkdir -p "$DASH/.backup/images-$TS/$(dirname "$PG")"; cp "$DASH/$PG" "$DASH/.backup/images-$TS/$PG"; }
cp "$HERE/files-dashboard/$PG" "$DASH/$PG" && echo "  ✓ $PG"

echo
echo "Backups em <repo>/.backup/images-$TS/"
echo "──────────────────────────────────────────────"
echo "IMPORTANTE: rode o pacote do BACKEND primeiro (db push de logoUrl/coverUrl)."
echo
echo "Depois, builde os dois repos:"
echo "  cd \"$DASH\" && npm run lint && npm run build"
echo "  cd \"$PUB\"  && npm run lint && npm run build"
echo "E suba cada um (git add -A && git commit && git push)."
echo "──────────────────────────────────────────────"
