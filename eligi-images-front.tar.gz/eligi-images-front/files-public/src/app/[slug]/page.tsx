'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { getProfile, PublicApiError } from '@/lib/api';
import { darken, coverBackground, isMonogramCover } from '@/lib/theme';
import { usePublicBookingStore } from '@/store/publicBooking.store';
import { Services } from '@/components/booking/Services';
import { DateTime } from '@/components/booking/DateTime';
import { Identify } from '@/components/identify/Identify';
import { Success } from '@/components/booking/Success';
import { formatPrice } from '@/lib/format';
import { formatSlotLabel } from '@/lib/datetime';

function initials(name: string): string {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map(w => w[0])
    .join('')
    .toUpperCase();
}

/** Logo (foto enviada) ou as iniciais como fallback. */
function Logo({ url, fallback }: { url: string | null; fallback: string }) {
  if (url) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img src={url} alt="" className="h-full w-full object-cover" />
    );
  }
  return <>{fallback}</>;
}

export default function PublicPage() {
  const params = useParams();
  const slug = typeof params?.slug === 'string' ? params.slug : '';

  const step = usePublicBookingStore(s => s.step);
  const profile = usePublicBookingStore(s => s.profile);
  const serviceId = usePublicBookingStore(s => s.serviceId);
  const professionalId = usePublicBookingStore(s => s.professionalId);
  const date = usePublicBookingStore(s => s.date);
  const time = usePublicBookingStore(s => s.time);
  const setProfile = usePublicBookingStore(s => s.setProfile);
  const setSlug = usePublicBookingStore(s => s.setSlug);
  const back = usePublicBookingStore(s => s.back);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!slug) return;
    let active = true;
    setSlug(slug);
    getProfile(slug)
      .then(p => {
        if (active) setProfile(p);
      })
      .catch((e: unknown) => {
        if (active) setError(e instanceof PublicApiError ? e.message : 'Não foi possível carregar.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [slug, setProfile, setSlug]);

  // Personalização: a cor da marca vai pras CSS vars globais (--brand etc.)
  // que os componentes (Services/DateTime/...) já consomem via Tailwind.
  // Primitivos nas deps (React Compiler) + restauro ao desmontar.
  const themePrimary = profile?.business.theme?.primary;
  const themeBg = profile?.business.theme?.bg;

  useEffect(() => {
    if (!themePrimary || !themeBg) return;
    const root = document.documentElement;
    const next: Record<string, string> = {
      '--brand': themePrimary,
      '--brand-strong': darken(themePrimary, 0.14),
      '--background': themeBg,
    };
    const prev: Record<string, string> = {};
    Object.keys(next).forEach(k => {
      prev[k] = root.style.getPropertyValue(k);
      root.style.setProperty(k, next[k]);
    });
    return () => {
      Object.keys(next).forEach(k => {
        if (prev[k]) root.style.setProperty(k, prev[k]);
        else root.style.removeProperty(k);
      });
    };
  }, [themePrimary, themeBg]);

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-neutral-300 border-t-brand" />
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-2 text-center">
        <p className="font-medium text-neutral-900">Estabelecimento não encontrado</p>
        {error && <p className="text-sm text-neutral-500">{error}</p>}
      </div>
    );
  }

  const biz = profile.business;
  const tz = biz.timezone;
  const location = [biz.city, biz.state].filter(Boolean).join(' · ');
  const isLanding = step === 'service';

  // Cores derivadas do tema do estabelecimento
  const theme = biz.theme;
  const primary = theme.primary;

  // Capa do painel: preset (gradient/glow/monogram) ou foto enviada (base64).
  const cover = coverBackground(biz.coverUrl, primary);
  const showWatermark = isMonogramCover(biz.coverUrl);

  const service = profile.services.find(s => s.id === serviceId) ?? null;
  const proName = professionalId
    ? (profile.professionals.find(p => p.id === professionalId)?.name ?? 'Profissional')
    : 'Sem preferência';

  // Painel de identidade (Modelo B) — capa derivada do tema + logo/monograma.
  const identityPanel = (
    <div className="relative overflow-hidden rounded-2xl p-7 text-white" style={{ background: cover.background }}>
      {showWatermark && (
        <div
          aria-hidden
          className="pointer-events-none absolute -bottom-10 -right-6 select-none font-bold leading-none"
          style={{ fontSize: 220, color: primary, opacity: 0.16 }}
        >
          {initials(biz.name).slice(0, 1)}
        </div>
      )}
      <div
        className="relative z-10 flex h-14 w-14 items-center justify-center overflow-hidden rounded-2xl bg-white text-lg font-semibold"
        style={{ color: primary }}
      >
        <Logo url={biz.logoUrl} fallback={initials(biz.name)} />
      </div>
      <h1 className="relative z-10 mt-5 text-xl font-semibold leading-tight tracking-tight">{biz.name}</h1>
      {location && <p className="relative z-10 mt-1.5 text-sm text-white/55">{location}</p>}
      <div className="relative z-10 mt-5 h-px w-10 bg-white/20" />
      <p className="relative z-10 mt-5 text-sm leading-relaxed text-white/65">Agende seu horário em segundos.</p>
    </div>
  );

  const summaryRail = (
    <div className="glass sticky top-10 rounded-2xl p-5">
      <p className="text-xs text-neutral-500">Resumo</p>
      <p className="mt-1 text-sm font-medium text-neutral-900">{service?.name ?? 'Serviço'}</p>
      <p className="mt-1 text-xs text-neutral-500">
        {date && time ? formatSlotLabel(date, time, tz) : 'Escolha data e horário'}
      </p>
      <p className="mt-1 text-xs text-neutral-400">{proName}</p>
      <p className="mt-3 text-lg font-semibold" style={{ color: primary }}>
        {formatPrice(service?.price ?? null)}
      </p>
    </div>
  );

  if (isLanding) {
    return (
      <div>
        {/* Mobile — faixa do topo agora usa a capa do tema */}
        <div className="md:hidden">
          <div
            className="relative flex h-28 items-center justify-center overflow-hidden rounded-b-2xl"
            style={{ background: cover.background }}
          >
            <div className="relative z-10 text-center text-white">
              <div
                className="mx-auto mb-2 flex h-12 w-12 items-center justify-center overflow-hidden rounded-full bg-white text-base font-medium"
                style={{ color: primary }}
              >
                <Logo url={biz.logoUrl} fallback={initials(biz.name)} />
              </div>
              <div className="text-base font-semibold">{biz.name}</div>
            </div>
          </div>
          <div className="px-1 pt-3">
            <h1 className="text-base font-semibold text-neutral-900">{biz.name}</h1>
            {location && <p className="text-xs text-neutral-500">{location}</p>}
          </div>
          <div className="mt-5 animate-[fadeIn_0.25s_ease]">
            <Services />
          </div>
        </div>

        {/* Desktop — Modelo B: painel de identidade + serviços */}
        <div className="hidden md:grid md:grid-cols-[320px_1fr] md:gap-6">
          <aside className="h-max md:sticky md:top-10 animate-[fadeIn_0.3s_ease]">{identityPanel}</aside>
          <div className="glass animate-[fadeIn_0.3s_ease] rounded-2xl p-6">
            <h2 className="mb-4 text-base font-semibold text-neutral-900">Escolha um serviço</h2>
            <Services />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="md:grid md:grid-cols-[300px_1fr] md:gap-6">
      <aside className="hidden h-max md:block">{summaryRail}</aside>

      <div className="space-y-5 pt-2 md:glass md:rounded-2xl md:p-6 md:pt-6">
        <header className="flex items-center gap-3">
          {step !== 'success' && (
            <button
              type="button"
              onClick={back}
              aria-label="Voltar"
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-neutral-200 text-neutral-700 transition hover:bg-neutral-100 active:scale-95"
            >
              ←
            </button>
          )}
          <h1 className="truncate text-sm font-semibold text-neutral-900">{biz.name}</h1>
        </header>

        <div key={step} className="animate-[fadeInUp_0.3s_ease]">
          {step === 'datetime' && <DateTime />}
          {step === 'identify' && <Identify />}
          {step === 'success' && <Success />}
        </div>
      </div>
    </div>
  );
}
